# ROMTEK Tasmota Relay Control

Android Studio project for controlling a Tasmota relay at **192.168.11.134**.

## Features
- Large ON/OFF control
- Reads current relay state from Tasmota
- Refresh status
- Editable relay IP (defaults to 192.168.11.134)
- Optional HTTP Basic Authentication fields
- Local-network HTTP communication; no cloud or MQTT required

## Build the APK
1. Install Android Studio (current stable) on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `ROMTEK-Tasmota-Relay` folder.
4. Allow Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location. Typically: `app/build/outputs/apk/debug/app-debug.apk`.

## Use
- Connect the Android phone to the same Wi-Fi/LAN as the relay.
- Launch **ROMTEK Relay Control**.
- The app automatically checks the relay on startup.
- Tap TURN ON or TURN OFF. Use Refresh status to query again.
- If Tasmota HTTP authentication is enabled, enter its username and password.

## Tasmota commands used
- Status: `GET http://192.168.11.134/cm?cmnd=Power`
- ON: `GET http://192.168.11.134/cm?cmnd=Power%20On`
- OFF: `GET http://192.168.11.134/cm?cmnd=Power%20Off`

## Notes
- This initial version controls the main Tasmota relay (`Power` / Relay 1).
- It uses plain HTTP because the standard Tasmota local web interface commonly uses HTTP. Use only on a trusted local network; do not expose the relay's HTTP interface directly to the internet.
- If the relay is configured with a URL prefix, reverse proxy, non-default web port, or a nonstandard command endpoint, the request URL will need adjusting.
