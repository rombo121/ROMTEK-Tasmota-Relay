package ca.romtek.tasmotarelay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

private const val DEFAULT_IP = "192.168.11.134"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RelayScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RelayScreen() {
    var ip by remember { mutableStateOf(DEFAULT_IP) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var relayOn by remember { mutableStateOf<Boolean?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Not connected yet") }
    val scope = rememberCoroutineScope()

    fun runCommand(command: String) {
        if (busy) return
        busy = true
        message = "Communicating with relay…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    tasmotaRequest(ip.trim(), command, username, password)
                }
                relayOn = result.first
                message = result.second
            } catch (e: Exception) {
                message = e.message ?: "Unable to reach relay"
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { runCommand("Power") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF42A5F5),
            background = Color(0xFF101820),
            surface = Color(0xFF1B2733)
        )
    ) {
        Scaffold(containerColor = Color(0xFF101820)) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState()).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("ROMTEK", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color(0xFF42A5F5))
                Text("TASMOTA RELAY CONTROL", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2733)),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("RELAY STATUS", color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            when (relayOn) { true -> "ON"; false -> "OFF"; null -> "UNKNOWN" },
                            color = when (relayOn) { true -> Color(0xFF66BB6A); false -> Color(0xFFEF5350); null -> Color.LightGray },
                            fontSize = 36.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = { runCommand(if (relayOn == true) "Power%20Off" else "Power%20On") },
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth().height(82.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (relayOn == true) Color(0xFFB3261E) else Color(0xFF187A43)
                            )
                        ) {
                            if (busy) CircularProgressIndicator(modifier = Modifier.size(26.dp), color = Color.White)
                            else {
                                Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(30.dp))
                                Spacer(Modifier.width(12.dp))
                                Text(if (relayOn == true) "TURN OFF" else "TURN ON", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { runCommand("Power") },
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Refresh status")
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("DEVICE SETTINGS", color = Color(0xFF90CAF9), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = ip, onValueChange = { ip = it },
                    label = { Text("Relay IP address") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = username, onValueChange = { username = it },
                    label = { Text("Tasmota username (if enabled)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("Tasmota password (if enabled)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(12.dp))
                Text(message, color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Text("Works on the same local Wi-Fi network as the relay.", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

/** Sends a Tasmota HTTP command and extracts the Power state from its JSON response. */
private fun tasmotaRequest(
    ip: String,
    command: String,
    username: String,
    password: String
): Pair<Boolean?, String> {
    require(ip.isNotBlank()) { "Enter the relay IP address." }
    val encodedCommand = command.replace(" ", "%20")
    val url = URL("http://$ip/cm?cmnd=$encodedCommand")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 5000
        readTimeout = 5000
        setRequestProperty("Accept", "application/json")
        if (username.isNotBlank()) {
            val credentials = Base64.getEncoder().encodeToString("$username:$password".toByteArray())
            setRequestProperty("Authorization", "Basic $credentials")
        }
    }

    try {
        val code = connection.responseCode
        if (code == 401) return Pair(null, "Authentication required. Check username and password.")
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) return Pair(null, "HTTP $code: ${body.take(160)}")
        val json = JSONObject(body)
        val state = json.optString("POWER", "").uppercase()
        return when (state) {
            "ON" -> Pair(true, "Connected • Relay is ON")
            "OFF" -> Pair(false, "Connected • Relay is OFF")
            else -> Pair(null, "Relay replied: ${body.take(180)}")
        }
    } finally {
        connection.disconnect()
    }
}
